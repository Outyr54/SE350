package visualization.model;

/**
 * Interface for active model objects.
 */
interface Agent {
  public void run(int time);
}

