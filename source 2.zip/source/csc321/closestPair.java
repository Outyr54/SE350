package csc321;

import java.util.*;
import static java.lang.Math.min;
import java.io.*;

public class closestPair {
	private Double x;
	private Double y;

	private static Double minDist = Double.POSITIVE_INFINITY;

	public closestPair(Double x, Double y) {
		this.x = x;
		this.y = y;
	}

	static double closest_Pair(closestPair[] p) {
		int n = p.length;
		mergeSort(p, 1, n);
		return rec_cl_pair(p, 1, n);
	}

	private static closestPair[] mergeSort(closestPair[] p, int low, int high) {
		if (low < high) {
			int middle = low + (high - low) / 2;
			mergeSort(p, low, middle);
			mergeSort(p, middle + 1, high);
			p = merge(p, low, middle, high);
		}
		return p;
	}

	private static closestPair[] merge(closestPair[] p, int low, int middle, int high) {

		closestPair[] helper = new closestPair[p.length];

		for (int i = low; i <= high; i++) {
			helper[i] = p[i];
		}

		int i = low;
		int j = middle + 1;
		int k = low;
		while (i <= middle && j <= high) {
			if (helper[i].x <= helper[j].x) {
				p[k] = helper[i];
				i++;
			} else {
				p[k] = helper[j];
				j++;
			}
			k++;
		}
		while (i <= middle) {
			p[k] = helper[i];
			k++;
			i++;
		}

		return p;
	}

	static double rec_cl_pair(closestPair[] p2, int i, int j) {
		if (j - i < 3) {
			mergeSort(p2, i, j);
			double delta = dist(p2[i], p2[i + 1]);
			if (j - i == 1)
				return delta;
			if (dist(p2[i + 1], p2[i + 2]) < delta)
				delta = dist(p2[i + 1], p2[i + 2]);
			if (dist(p2[i], p2[i + 2]) < delta)
				delta = dist(p2[i], p2[i + 2]);
			return delta;
		}
		int k = (i + j) / 2;
		double l = p2[k].x;
		double deltaL = rec_cl_pair(p2, i, k);
		double deltaR = rec_cl_pair(p2, k + 1, j);
		double delta = min(deltaL, deltaR);
		p2 = merge(p2, i, k, j);

		int t = 0;

		closestPair[] v = new closestPair[j + 1];

		for (int k2 = i; k2 < j; k2++) {
			if ((p2[k2].x > l - delta) && p2[k2].x < l + delta) {
				t = t + 1;
				v[t] = p2[k2];
			}
		}
		for (int k2 = 1; k2 < t - 1; k2++) {
			for (int s = k2 + 1; k2 < min(t, k2 + 7); s++) {
				delta = min(delta, dist(v[k], v[s]));
				minDist = delta;
				return delta;
			}
		}
		return minDist;
	}

	private static Double dist(closestPair p1, closestPair p2) {
		double xdistance = p2.x - p1.x;
		double ydistance = p2.y - p1.y;
		return Math.hypot(xdistance, ydistance);
	}

	public static void main(String[] args) throws IOException {
		File file = new File("data/10points.txt");
		Scanner scanner = new Scanner(file);

		ArrayList<closestPair> arrayList = new ArrayList<closestPair>();

		for (double i = 0, n = scanner.nextDouble(); i < n; i++) {
			arrayList.add(new closestPair(scanner.nextDouble(), scanner.nextDouble()));
		}
		scanner.close();

		System.out.println(arrayList);
	}
}