package shop.data;

/**
 * Implementation of Video interface.
 * @see Data
 */
final class VideoObj implements Video {
  private final String _title;
  private final int    _year;
  private final String _director;

  /**
   * Initialize all object attributes.
   * Title and director are "trimmed" to remove leading and final space.
   * @throws IllegalArgumentException if object invariant violated.
   */
  VideoObj(String title, int year, String director) {
    _title = title;
    _director = director;
    _year = year;
  }

  public String director() {
    // TODO  
    return _director;
  }

  public String title() {
    // TODO  
    return _title;
  }

  public int year() {
    // TODO  
    return _year;
  }

  public boolean equals(Object thatObject) {
    // TODO  
	  if (!(thatObject instanceof VideoObj))
			return false;

		// Cast onto object
		VideoObj th = (VideoObj) thatObject;

		return th._director.equals(_director) && th._title.equals(_title) && th._year == _year;

  }

  public int hashCode() {
    // TODO  
	  int res = 17;
	  res = 37 * res + _title.hashCode();
	  res = 37 * res + _year;
	  res = 37 * res + _director.hashCode();
	  
	  return res;
  }

  public int compareTo(Object thatObject) {
    // TODO  
	  if (thatObject == null)
			throw new NullPointerException();
		if (!(thatObject instanceof VideoObj))
			throw new ClassCastException();
		VideoObj th = (VideoObj) thatObject;

		int titleCompare = _title.compareTo(th._title);
		if (titleCompare != 0)
			return titleCompare;

		int yearCompare = _year - th._year;
		if (yearCompare != 0)
			return yearCompare;

		int directorCompare = _director.compareTo(th._director);
		if (directorCompare != 0)
			return directorCompare;

		return 0;
	}

  public String toString() {
    // TODO  
	  String movieDesc = _title + " (" + _year + ") : " + _director;
	  return movieDesc;
	}
}
