package shop.ui;

public interface UIFactoryInterface {
    String popup = "popup";
    String textui = "text";
    String UIFormBuilder = "UIFB";
    String UIFormMenu = "UIFM";
    String UIMenuBuilder = "UIMB";
}