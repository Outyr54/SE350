package hw2;
public class MyLinked {
    static class Node {
        public Node() { }
        public double item;
        public Node next;
    }

    int N;
    Node first;
    
    public MyLinked () {
        first = null;
        N = 0;
        assert checkInvariants ();
    }


    private boolean checkInvariants() {
        assert((N != 0) || (first == null));
        Node x = first;
        for (int i = 0; i < N; i++) {
            if (x==null) {
                return false;
            }
            x = x.next;
        }
        assert(x == null);
        return true;
    }

    public boolean isEmpty () { return first == null; }
    public int size () { return N; }
    public void add (double item) {
        Node newfirst = new Node ();
        newfirst.item = item;
        newfirst.next = first;
        first = newfirst;
        N++;
    }


    // delete the kth element
    public void delete (int k) {
    	if (k < 0 || k >= N) throw new IllegalArgumentException ();

        Boolean deletedNode = false;

        if(k==0 && N==1) {
        	first = null;
        	deletedNode = true;
        }
  
        if(!deletedNode && k==1 && N==2) {
        	first.next = null;
        	deletedNode = true;
        }
        
        if(!deletedNode && k==0) {
        	first = first.next;
        	deletedNode = true;
        }
        
        if(!deletedNode && k==N-1) {
        	Node x = first;
            for (int i = 0; i < N; i++) {
                if (i==N-2) {
                    x.next = null;
                    deletedNode = true;
                    break;
                }
                x = x.next;
            }
        }
        
        if(!deletedNode) {
        	Node x = first;
        	for(int i = 1; i < N; i++) {
        		if(k==i) {
        			x.next = x.next.next;
        			deletedNode = true;
        			break;
        		}
        		x = x.next;
        	}
        }
        
        assert deletedNode;
        N--;
        assert checkInvariants ();
    }
    // reverse the list "in place"... without creating any new nodes
    public void reverse () {
    
    	if(first==null || first.next==null) return;

        assert checkInvariants ();
    }

    // remove 
    public void remove (double item) {
        
    	if(first==null) return;
    	while(first!=null && first.item==item) {
    		if(first.next==null) { 
    			first = null; 
    			N--;
    		}
    		else { 
    			first = first.next;
    			N--;
    		}
    	}
  
		Node a = first;
		Node b = first;
		while(a!=null) {
			while(a!=null && a.item!=item) {
				b = a;
				a = a.next;
			}
			if(a==null) { return; }
			b.next = a.next; 
			a = a.next;
			N--;
		}    
        assert checkInvariants ();
    }

}