package delegateObserver;
public interface Counter extends MyObservable{
	public void inc();
	public int getI ();

}
