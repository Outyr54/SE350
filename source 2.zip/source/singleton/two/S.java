package singleton.two;          
public interface S {
  public int inc();
}
