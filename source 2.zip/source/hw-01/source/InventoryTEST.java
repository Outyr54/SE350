import junit.framework.Assert;
import junit.framework.TestCase;
import java.util.Iterator;
import java.util.Set;
import java.util.Collection;
import java.util.HashSet;

// TODO:  complete the tests
public class InventoryTEST extends TestCase {	
	InventorySet set = new InventorySet();
	final VideoObj vid1 = new VideoObj("The Dark Knight", 2008, "Christopher Nolan");
	final VideoObj vid2 = new VideoObj("Scarface", 1983, "Brian De Palma");
	
  public InventoryTEST(String name) {
    super(name);
  }

  // TODO  
  
  public void testSize() {
    // TODO  
	set.clear();
	assertEquals(0, set.size());
	
	set.addNumOwned(vid1, 1);
	assertEquals(1, set.size());
	
	set.addNumOwned(vid1, 15);
	assertEquals(1, set.size());
	
	set.addNumOwned(vid2, 300);
	assertEquals(2, set.size());
	
	set.addNumOwned(vid2, -301);
	assertEquals(1, set.size());
	
	try {
		set.addNumOwned(null, -1);
		fail("Exception is thrown");
	} catch(IllegalArgumentException e) {}
  }

  public void testAddNumOwned() {
    // TODO
	set.clear();
	assertEquals(0, set.size());
	
	set.addNumOwned(vid1, 1);
	assertEquals(1, set.get(vid1).numOwned);
	
	set.addNumOwned(vid1, 500);
	assertEquals(501, set.get(vid1).numOwned);
	
	set.addNumOwned(vid1, -300);
	assertEquals(201, set.get(vid1).numOwned);
	
	set.addNumOwned(vid2, 5);
	assertEquals(5, set.get(vid2).numOwned);
	
	assertEquals(2, set.size());
	
	try {
		set.addNumOwned(null, -1);
		fail("Exception is thrown");
	} catch(IllegalArgumentException e) {}
	
	try {
		set.addNumOwned(vid1, 0);
		fail("Exception is thrown");
	} catch (IllegalArgumentException e) {}
  }
  
  public void testCheckOutCheckIn() {
    // TODO  
	try {
		set.checkIn(null);
		fail("Exception is thrown");
	} catch(IllegalArgumentException e) {}
	
	try {
		set.checkOut(null);
		fail("Exception is thrown");
	} catch(IllegalArgumentException e) {}
	
	set.addNumOwned(vid1, 1);
	assertTrue(set.get(vid1).numOut == 0 && set.get(vid1).numRentals == 0);
	
	try {
		set.checkIn(vid1);
		fail("Exception is thrown");
	} catch(IllegalArgumentException e) {}
	
	
	set.checkOut(vid1);
	try {
		set.checkOut(vid1);
		fail("Exception is thrown");
	} catch(IllegalArgumentException e) {}
  }

  public void testClear() {
    // TODO
	set.clear();
	assertEquals(0, set.size());
	
	set.addNumOwned(vid1, 2);
	set.addNumOwned(vid2, 30);
	
	assertEquals(2, set.size());
	
	set.clear();
	assertEquals(0, set.size());
	
	try {
		set.checkOut(vid1);
		fail("Exception is thrown");
	} catch(IllegalArgumentException e) {}
  }

  public void testGet() {
    // TODO  
	set.clear();
	assertNull(set.get(vid1));
	
	set.addNumOwned(vid1, 1);
	//assertNull(set.get(vid1));
	
	Record rec1 = set.get(vid1);
	Record rec2 = set.get(vid2);
	assertFalse(rec1.equals(rec2));
	assertTrue(rec1 != rec2);
  }

  public void testToCollection() {
    // Be sure to test that changing records in the returned
    // collection does not change the original records in the
    // inventory.  ToCollection should return a COPY of the records,
    // not the records themselves.
    // TODO  
	  set.clear();
		
		assertTrue(set.toCollection() != set.toCollection()); //Addresses should be different if they were copies
		
		set.addNumOwned(vid1, 1);
		Collection<Record> recordAL = set.toCollection(); //Both should contain 1 of vid1
		
		set.addNumOwned(vid1, 15); //Inventory contains 16 of vid 1, but the copy should still contain 1
		assertTrue(set.get(vid1).numOwned != recordAL.iterator().next().numOwned); //Verify if above is true
		
		set.addNumOwned(vid2, 2); //Adding another record to the inventory. The copy should still be just 1 record
		assertEquals(2, set.size());
		assertEquals(1, recordAL.size());
		
		set.clear(); //Nothing should be in inventory
		assertEquals(0, set.size());
		assertEquals(1, recordAL.size()); //But the copy should still contain 1 record
	}
}
