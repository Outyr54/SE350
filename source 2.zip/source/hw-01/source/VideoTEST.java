
//import junit.framework.Assert;
import org.junit.Assert;

import junit.framework.TestCase;

// TODO:  complete the tests
public class VideoTEST extends TestCase {

	
	public VideoTEST(String name) {
		super(name);
	}

	public void testConstructorAndAttributes() {
		String title1 = "XX";
		String director1 = "XY";
		String title2 = " XX ";
		String director2 = " XY ";
		int year = 2002;

		VideoObj v1 = new VideoObj(title1, year, director1);
		assertSame(title1, v1.title());
		assertEquals(year, v1.year());
		assertSame(director1, v1.director());

		VideoObj v2 = new VideoObj(title2, year, director2);
		assertEquals(title1, v2.title());
		assertEquals(director1, v2.director());
	}
	
	public void testConstructorExceptionYear() {
		try {
			new VideoObj("X", 1800, "Y");
			Assert.fail();
		} catch (IllegalArgumentException e) {
		}
		try {
			new VideoObj("X", 5000, "Y");
			Assert.fail();
		} catch (IllegalArgumentException e) {
		}
		try {
			new VideoObj("X", 1801, "Y");
			new VideoObj("X", 4999, "Y");
		} catch (IllegalArgumentException e) {
			Assert.fail();
		}
	}

	public void testConstructorExceptionTitle() {
		try {
			new VideoObj(null, 2002, "Y");
			Assert.fail();
		} catch (IllegalArgumentException e) {
		}
		try {
			new VideoObj("", 2002, "Y");
			Assert.fail();
		} catch (IllegalArgumentException e) {
		}
		try {
			new VideoObj(" ", 2002, "Y");
			Assert.fail();
		} catch (IllegalArgumentException e) {	}
	}

	public void testConstructorExceptionDirector() {
		// TODO
	}

	public void testHashCode() {
		VideoObj obj = new VideoObj("Hello", 1999, "Hey");
		int hash = 17;
		hash = 37 * hash + obj.title().hashCode();
		hash = 37 * hash + obj.year();
		hash = 37 * hash + obj.director().hashCode();
		assert (obj.hashCode() == hash);
	}

	public void testEquals() {
		VideoObj vid1 = new VideoObj("None", 2009, "Nurple");
		VideoObj vid2 = new VideoObj("None", 2009, "Nurple");
		VideoObj vid3 = new VideoObj("None", 2009, "Nurple");
		
		assertTrue(vid1.equals(vid1)); 
		assertTrue(vid1.equals(new VideoObj("None", 2009, "Nurple")));
		assertTrue(vid1.equals(vid2) && vid2.equals(vid3) && vid1.equals(vid3)); 
		assertFalse(vid1.equals(new VideoObj("None", 2010, "Nurple"))); 
		assertFalse(vid1.equals(new VideoObj("Something", 2009, "Chips"))); 
		assertFalse(vid1.equals(new VideoObj("None", 2009, "Biple"))); 
		assertFalse(vid1.equals(new VideoObj("Something", 2010, "Fruby")));
		assertFalse(vid1.equals(new Object())); 
		assertFalse(vid1.equals(null)); 
	}

	public void testCompareTo() {
		String title1 = "A", title2 = "B";
		int year1 = 2000, year2 = 2010;
		String dir1 = "Chips", dir2 = "Marcus";
		
		VideoObj vid1 = new VideoObj(title1, year1, dir1);
		VideoObj vid2 = new VideoObj(title2, year2, dir2);
		
		assertTrue(vid1.compareTo(vid2) < 0); 
		assertTrue(vid1.compareTo(vid2) == -vid2.compareTo(vid1));
		assertTrue(vid1.compareTo(vid1) == 0); 
		
		try {
			vid1.compareTo(new Object());
			fail("Exception is thrown");
		} catch(ClassCastException e) {}
		
		try {
			vid1.compareTo(null);
			fail("Exception is thrown");
		} catch(NullPointerException e) {}
		catch (ClassCastException e) {}
		
		
	}
 
	public void testToString() {
		VideoObj vid1 = new VideoObj("None", 2009, "Nurple");
		VideoObj vid2 = new VideoObj("Derp", 1954, "Chips");
		
		String answer = "None (2009) : Nurple";
		assertTrue(vid1.toString().equals(answer));
		assertFalse(vid2.toString().equals(answer));
		}
}
