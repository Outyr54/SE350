package hw3;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;

import org.junit.jupiter.api.Test;

class fptest {
	
	@Test
	void testMap() {
		List<String> names = new ArrayList<String>();
		
		names.add("Mary");
		names.add("Isla");
		names.add("Sam");
		
		List<Integer> hashCodes = new ArrayList<Integer>();
		for(int x = 0; x < names.size(); x++)
			hashCodes.add(names.get(x).hashCode());
			
		Function<String, Integer> f = (str) ->{
			return(str.hashCode());
		};
		
		List<Integer> result = new ArrayList<Integer>();
		result = fp.map(names, f);
		
		for(int x = 0; x < hashCodes.size(); x++)
			assertEquals(hashCodes.get(x), result.get(x));
	}
	
	@Test
    void testFoldLeft(){
        List<Integer> l = new ArrayList<Integer>();
        
        for(int x = 0; x < 5; x++)
        	l.add(x);
        
        BiFunction<String, Integer, String> f = (p, q) ->{
        	return (p + "[" + q + "]");
        };
        
        assertEquals("@[0][1][2][3][4]", fp.foldLeft("@", l, f));
        assertEquals("@", fp.foldLeft("@", null, f));
    }
	
	@Test
	void testFoldRight() {
		List<Integer> a = new ArrayList<Integer>();
		
		for (int x = 0; x < 5; x++) {
			a.add(x);
		}
		
		BiFunction<Integer, String, String> f = (p, q) -> {
			return (q + "[" + p + "]");
		};

        assertEquals("@", fp.foldRight("@", null, f));
        assertEquals("@[4][3][2][1][0]", fp.foldRight("@", a, f));
	}
	
	 @Test
	    void testFilter(){
	        Iterable<Person> employees = new ArrayList<Person>();
	        
	        ((ArrayList<Person>) employees).add(new Person(1, "Under1"));
	        ((ArrayList<Person>) employees).add(new Person(2, "Under2"));
	        ((ArrayList<Person>) employees).add(new Person(100001, "Over1"));
	        ((ArrayList<Person>) employees).add(new Person(111111, "Over2"));

	        Predicate<Person> greaterThan100k = (Person person) -> person.getSalary() < 100000;
	        employees = fp.filter(employees, greaterThan100k);
	        
	        String result = "";
	        for(Person p : employees){
	            result += p.name();
	        }
	        
	        assertEquals("Over1Over2", result);
	    }
	 @Test
	 	void testMinPos() {
		 List<Integer> numList = List.of(5, 10, 15, 20, 22, 1);
		 System.out.println(fp.minVal(numList, Integer::compare));
	 }
	
}